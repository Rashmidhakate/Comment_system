$(document).ready(function(){
	$.ajax({
		url:"show_comments.php",
		method:"POST",
		success:function(response) {
			$('#showComments').html(response);
			var $response=$(response);
			$(response).each(function(){
				var id = $(this).find('.panel-footer button').attr('id');
				showReplyComments(id);
			});
		}
	});
	$('#commentForm').on('submit', function(event){
		event.preventDefault();
		var formData = $(this).serialize();
		$.ajax({
			url: "comments.php",
			method: "POST",
			data: formData,
			dataType: "JSON",
			success:function(response) {
				console.log(response);
				if(!response.error) {
					$('#commentForm')[0].reset();
					$('#commentId').val('0');
					$('#message').html(response.message);
					// showComments();
					//console.log(response.lastId);
					//showReplyComments(response.parent_id);	
					//console.log(response.parent_id);
					if(response.parent_id == 0){
						showComments();	
					}else{
						showReplyComments(response.parent_id);
					}
				} else if(response.error){
					$('#message').html(response.message);
				}
			}
		})
	});
});

$(document).on('click', '.reply', function(){
	var commentId = $(this).attr("id");
	$('#commentId').val(commentId);
	$('#name').focus();
});

function showComments() {
	$.ajax({
		url:"show_comments.php",
		method:"POST",
		success:function(response) {
			$('#showComments').html(response);
		}
	})
}

// function replyComments(commentId) {
// 	$('#commentForm').on('submit', function(event){
// 		event.preventDefault();
// 		var formData = {commentId : commentId ,name : $('#name').val() , comment : $('#comment').val()};
// 		$.ajax({
// 			url: "comments.php",
// 			method: "POST",
// 			data: formData,
// 			dataType: "JSON",
// 			success:function(response) {
// 				if(!response.error) {
// 					$('#commentForm')[0].reset();
// 					$('#commentId').val(commentId);
// 					$('#message').html(response.message);
// 					showReplyComments(commentId);
// 				} else if(response.error){
// 					$('#message').html(response.message);
// 				}
// 			}
// 		})
// 	});
// }


function showReplyComments(commentId){
	$.ajax({
		url:"show_comments.php",
		method:"POST",
		data: {parentId : commentId},
		success:function(response) {
			$('#reply_comment'+commentId).html(response);
		}
	})
}